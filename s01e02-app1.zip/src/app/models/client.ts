export interface Client {
    id: number;
    name: string;
    surname: string;
    email: string;
    phone?: string;
}